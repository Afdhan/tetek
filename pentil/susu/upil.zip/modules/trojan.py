from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
	async def trojan_(event):
		inline = [
	[Button.inline("[ Trial Trojan ]","trial-trojan"),
	Button.inline("[ Create Trojan ]","create-trojan")],
	[Button.inline("[ Delete Trojan ]","delete-trojan"),
	Button.inline("[ Check Trojan Login ]","login-trojan")],
	[Button.inline("[ BACK TO MENU ]","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
	======================
		 	Trojan Menu 
	======================
	Service: `Trojan`
	Hostname/IP: `{DOMAIN}`
	ISP: `{z["isp"]}`
	Country: `{z["country"]}`
	======================
	- By DhanZaa Group
	======================
	"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
