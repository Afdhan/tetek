from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
	[Button.inline("[ Trial VMess ]","trial-vmess"),
	Button.inline("[ Create VMess ]","create-vmess")],
	[Button.inline("[ Delete VMess ]","delete-vmess"),
	Button.inline("[ Check VMess Login ]","login-vmess")],
	[Button.inline("[ BACK TO MENU ]","menu")]]
	z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
	msg = f"""
	======================
		 	VMESS Menu 
	======================
	Service: `VMESS`
	Hostname/IP: `{DOMAIN}`
	ISP: `{z["isp"]}`
	Country: `{z["country"]}`
	======================
	- By DhanZaa Group
	======================
	"""
	await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)
