from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'login-ssws'))
async def login_ssws(event):
	async def login_ssws_(event):
		x = subprocess.check_output('cek-ssws',shell=True).decode("ascii")
		inline = [
		[Button.inline("[ Delete SS WS ]","delete-ssws")],
		[Button.inline("[ BACK TO MENU ]","menu")]
	]
		date = DT.date.now()
		text2png(u"%s" % x, 'login_ssws.png', fontfullpath = "wsc_panel/font.ttf")
		await event.respond(f"""
	Check Login SS WS
	Date: `{date}`
	""",file="login_ssws.png", buttons=inline)
		os.remove("login_ssws.png")
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssws_(event)
	else:
		await event.answer("Access Denied",alert=True)
