from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'login-trojan'))
async def login_trojan(event):
	async def login_trojan_(event):
		x = subprocess.check_output('cek-tr',shell=True).decode("ascii")
		inline = [
		[Button.inline("[ Delete Trojan ]","delete-trojan")],
		[Button.inline("[ BACK TO MENU ]","menu")]
	]
		date = DT.date.now()
		text2png(u"%s" % x, 'login_trojan.png', fontfullpath = "wsc_panel/font.ttf")
		await event.respond(f"""
	Check Login Trojan
	Date: `{date}`
	""",file="login_trojan.png", buttons=inline)
		os.remove("login_trojan.png")
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)
