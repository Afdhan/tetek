from xolpanel import *

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = str(random.randint(1,100))
		exp = "1"
		cmd = f'add-ssh-json -u {user} -p {pw} -v {exp}'
		try:
			subprocess.check_output(cmd,shell=True)
		except subprocess.CalledProcessError as e:
			await event.respond(f"Command failed with return code {e.returncode}")
		else:
			try:
				res = requests.get(f'http://{DOMAIN}:{PORT_NGINX}/{user}-ssh.json').json()
				res.raise_for_status()
			except requests.exceptions.HTTPError as e:
				await event.respond(f"Requests HTTP Error {e.response.text}")
			else:
			# today = DT.date.today()
			# later = today + DT.timedelta(days=int(exp))
	if res["status"] == "success":
		msg = f"""
		======================
			Trial SSH Account
		======================
		IP Adress: {res["data"]["ip_address"]}
		Hostname: {DOMAIN}
		Username: {user.strip()}
		Password: {pw.strip()}
		======================
		OpenSSH: {res["data"]["port_openssh"]}
		Dropbear: {res["data"]["port_dropbear"]}
		SSL/TLS: {res["data"]["port_ssl"]}
		WebSocket: {res["data"]["port_ws"]}
		WebSocket TLS: {res["data"]["port_wsssl"]}
		BadVPN: {res["data"]["udpgw"]}
		Squid: {res["data"]["squid"]}
		======================
		UDP Custom: {res["data"]["udp_custom"]}
		======================
		Name Server: {res["data"]["ns"]}
		PubKey: {res["data"]["pubkey"]}
		Port DNS: {res["data"]["port_ns"]}
		======================
		Default Payload: 
		{res["data"]["payload_ws"]}
		======================
		WSS Payload: 
		{res["data"]["payload_wss"]}
		======================
		Expiry date: {res["data"]["exp"]}
		======================
		Script By DhanZaa Group
		"""
		# msg = f"""
		# 	**━━━━━━━━━━━━━━━━**
		# 	**⟨ SSH Account ⟩**
		# 	**━━━━━━━━━━━━━━━━**
		# 	**» Host:** `{DOMAIN}`
		# 	**» Username:** `{user.strip()}`
		# 	**» Password:** `{pw.strip()}`
		# 	**━━━━━━━━━━━━━━━━**
		# 	**» OpenSSH:** `22`
		# 	**» SSL/TLS:** `222`, `777`, `443`
		# 	**» Dropbear:** `109`,`143`
		# 	**» WS SSL:** `443`
		# 	**» WS HTTP:** `80`, `8080`
		# 	**» Squid:** `8080`, `3128` `(Limit To IP Server)`
		# 	**» BadVPN UDPGW:** `7100` **-** `7300`
		# 	**━━━━━━━━━━━━━━━━**
		# 	**⟨ Payload WS  ⟩**
		# 	`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
		# 	**⟨ Payload WS SSL ⟩**
		# 	`GET wss:/// HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf]Connection: Keep-Alive[crlf][crlf]`
		# 	**━━━━━━━━━━━━━━━━**
		# 	**» 🗓Expired Until:** `{later}`
		# 	**» 🤖@givpn**
		# 	**━━━━━━━━━━━━━━━━**
		# 	"""
		# pass
	else:
		msg = f'{res["message"]}'

		inline = [
				[Button.url("[ WhatsApp Group ]","https://chat.whatsapp.com/BhUUxWSaoNEF5kxc7OMPMF")]
				await event.respond(msg,buttons=inline)
		chat = event.chat_id
		sender = await event.get_sender()
		a = valid(str(sender.id))
		if a == "true":
			await create_ssh_(event)
		else:
			await event.answer("Access Denied",alert=True)
