from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:

			x = subprocess.check_output('del-ws',shell=True).decode("ascii")
			text2png(u"%s" % x, 'mem_vmess.png', fontfullpath = "wsc_panel/font.ttf")
			await event.respond(f"""
			Input Remarks To Be Deleted:
			""",file="mem_vmess.png")
			os.remove("mem_vmess.png")
			# await event.respond("Input Username To Be Deleted:")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		try:
			subprocess.check_output(f"del-ws -u {user}",shell=True)
		except:
			await event.respond(f"User `{user}` Not Found")
		else:
			await event.respond(f"Successfully Deleted `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
