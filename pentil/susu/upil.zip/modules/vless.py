from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
	[Button.inline("[ Trial VLess ]","trial-vless"),
	Button.inline("[ Create VLess ]","create-vless")],
	[Button.inline("[ Delete VLess ]","delete-vless"),
	Button.inline("[ Check VLess Login ]","login-vless")],
	[Button.inline("[ BACK TO MENU ]","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
	======================
		 	VLESS Menu 
	======================
	Service: `VLESS`
	Hostname/IP: `{DOMAIN}`
	ISP: `{z["isp"]}`
	Country: `{z["country"]}`
	======================
	- By DhanZaa Group
	======================
	"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
