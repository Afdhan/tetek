from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'ssws'))
async def ssws(event):
	async def ssws_(event):
		inline = [
	[Button.inline("[ Trial SS WS ]","trial-ssws"),
	Button.inline("[ Create SS WS ]","create-ssws")],
	[Button.inline("[ Delete SS WS ]","delete-ssws"),
	Button.inline("[ Check SS WS Login ]","login-ssws")],
	[Button.inline("[ BACK TO MENU ]","menu")]]
	z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
	msg = f"""
	======================
		 	SS WS Menu 
	======================
	Service: `Shadowsocks WS`
	Hostname/IP: `{DOMAIN}`
	ISP: `{z["isp"]}`
	Country: `{z["country"]}`
	======================
	- By DhanZaa Group
	======================
	"""
	await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssws_(event)
	else:
		await event.answer("Access Denied",alert=True)
