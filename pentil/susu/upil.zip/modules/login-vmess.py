from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'login-vmess'))
async def login_vmess(event):
	async def login_vmess_(event):
		x = subprocess.check_output('cek-ws',shell=True).decode("ascii")
		inline = [
		[Button.inline("[ Delete VMess ]","delete-vmess")],
		[Button.inline("[ BACK TO MENU ]","menu")]
	]
		date = DT.date.now()
		text2png(u"%s" % x, 'login_vmess.png', fontfullpath = "wsc_panel/font.ttf")
		await event.respond(f"""
	Check Login VMess
	Date: `{date}`
	""",file="login_vmess.png", buttons=inline)
		os.remove("login_vmess.png")
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)
