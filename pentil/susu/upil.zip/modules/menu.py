from wsc_panel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
		[Button.inline("[ SSH ]","ssh"), Button.inline("[ VMESS ]","vmess")],
		[Button.inline("[ VLESS ]","vless")],
		[Button.inline("[ TROJAN ]","trojan"), Button.inline("[ SS WS ]","ssws")],
		[Button.url("[ WhatsApp Group ]","https://chat.whatsapp.com/BhUUxWSaoNEF5kxc7OMPMF")]
	]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Access Denied", alert=True)
		except:
			await event.reply("Access Denied")
	elif val == "true":
		msg = f"""
	======================
			BOT MENU
	======================
	Bot version: 0.1.10
	Python Version: 3.12.1
	Telethon Version: 1.33.1
	Authors: DhanZaa Group
	Owner: @RismaVPN
	======================
	"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
