
from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
	async def create_trojan_(event):
		async with bot.conversation(chat) as user:
			await event.respond('Create Remarks...')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("Select An Expiration Date",buttons=[
				[Button.inline("[ 3 Days ]","3"),
				Button.inline("[ 7 Days ]","7")],
				[Button.inline("[ 15 Days ]","15"),
				Button.inline("[ 30 Days ]","30")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
    	cmd = f'add-tr-json -u {user} -v {exp}'
		try:
			subprocess.check_output(cmd,shell=True)
		except subprocess.CalledProcessError as e:
			await event.respond(f"Command failed with return code {e.returncode}")
		else:
			try:
				res = requests.get(f'http://{DOMAIN}:{PORT_NGINX}/{user}-tr.json').json()
				res.raise_for_status()
			except requests.exceptions.HTTPError as e:
				await event.respond(f"Requests HTTP Error {e.response.text}")
			else:

	if res["status"] == "success":
		msg = f"""
		======================
			Trojan Account
		======================
		Hostname: {DOMAIN}
		Remarks: {user.strip()}
		======================
		Port TLS: {res["data"]["port_tls"]}
		Port HTTP: {res["data"]["port_ntls"]}
		Port gRPC: {res["data"]["port_grpc"]}
		======================
		UUID: {res["data"]["uuid"]}
		Path: {res["data"]["path"]}
		ServiceName: {res["data"]["servicename"]}
		======================
		Link TLS: 
		{res["data"]["link_tls"]}
		======================
		Link HTTP: 
		{res["data"]["link_ntls"]}
		======================
		Link gRPC: 
		{res["data"]["link_grpc"]}
		======================
		Expiry date: {res["data"]["exp"]}
		======================
		Script By DhanZaa Group
		"""
	else:
		msg = f'{res["message"]}'

		inline = [
				[Button.url("[ WhatsApp Group ]","https://chat.whatsapp.com/BhUUxWSaoNEF5kxc7OMPMF")]
				await event.respond(msg,buttons=inline)
		chat = event.chat_id
		sender = await event.get_sender()
		a = valid(str(sender.id))
		if a == "true":
			await create_trojan_(event)
		else:
			await event.answer("Access Denied",alert=True)
