from wsc_panel import *

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		x = subprocess.check_output('cek',shell=True).decode("ascii")
		date = DT.date.now()
		inline = [
		[Button.inline("[ Delete SSH ]","delete-ssh")],
		[Button.inline("[ BACK TO MENU ]","menu")]
	]
		text2png(u"%s" % x, 'login_ssh.png', fontfullpath = "wsc_panel/font.ttf")
		await event.respond(f"""
	Check Login SSH
	Date: `{date}`
	""",file="login_ssh.png", buttons=inline)
		os.remove("login_ssh.png")
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
